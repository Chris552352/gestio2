<?php
// Éviter de démarrer la session si elle est déjà active
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Fonction pour vérifier si l'utilisateur est connecté
function estConnecte() {
    return isset($_SESSION['utilisateur_id']);
}

// Fonction pour vérifier si l'utilisateur est un admin
function estAdmin() {
    return estConnecte() && $_SESSION['role'] === 'admin';
}

// Fonction pour vérifier si l'utilisateur est un enseignant
function estEnseignant() {
    return estConnecte() && $_SESSION['role'] === 'enseignant';
}

// Fonction pour rediriger vers la page de connexion si l'utilisateur n'est pas connecté
function verifierConnexion() {
    if (!estConnecte()) {
        $_SESSION['message_erreur'] = "Veuillez vous connecter pour accéder à cette page.";
        header('Location: login.php');
        exit();
    }
}

// Fonction d'authentification utilisateur
function authentifier($email, $mot_de_passe, $pdo) {
    // Mode démo SQLite
    if (get_class($pdo) === 'PDO' && $pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite') {
        // En mode démo, accepter l'identifiant de démo
        if ($email === 'chris552352@gmail.com' && $mot_de_passe === '552352') {
            // Création des variables de session pour le mode démo
            $_SESSION['utilisateur_id'] = 1;
            $_SESSION['nom'] = 'Dupont';
            $_SESSION['prenom'] = 'Chris';
            $_SESSION['email'] = 'chris552352@gmail.com';
            $_SESSION['role'] = 'enseignant';
            
            return true;
        } else {
            return false;
        }
    }

    try {
        $stmt = $pdo->prepare("SELECT id, nom, prenom, email, mot_de_passe, role FROM utilisateurs WHERE email = :email");
        $stmt->execute(['email' => $email]);
        $utilisateur = $stmt->fetch();
        
        if ($utilisateur && password_verify($mot_de_passe, $utilisateur['mot_de_passe'])) {
            // Mise à jour de la dernière connexion (adapté pour MySQL)
            $stmt = $pdo->prepare("UPDATE utilisateurs SET derniere_connexion = NOW() WHERE id = :id");
            $stmt->execute(['id' => $utilisateur['id']]);
            
            // Création des variables de session
            $_SESSION['utilisateur_id'] = $utilisateur['id'];
            $_SESSION['nom'] = $utilisateur['nom'];
            $_SESSION['prenom'] = $utilisateur['prenom'];
            $_SESSION['email'] = $utilisateur['email'];
            $_SESSION['role'] = $utilisateur['role'];
            
            return true;
        }
        return false;
    } catch (PDOException $e) {
        // En cas d'erreur, on retourne false
        return false;
    }
}

// Fonction de déconnexion
function deconnecter() {
    // Supprimer toutes les variables de session
    $_SESSION = array();
    
    // Détruire la session
    session_destroy();
}
?>
